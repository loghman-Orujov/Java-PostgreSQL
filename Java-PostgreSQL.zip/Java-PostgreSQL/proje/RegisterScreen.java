package proje;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;

public class RegisterScreen extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField usernameField;
	private JPasswordField passwordField;
	private JTextField fnameField;
	private JTextField lnameField;
	private JTextField phoneNoField;
	private JTextField emailField;
	private JTextField addressField;
	private JLabel passwordLabel;
	private JLabel fnameLabel;
	private JLabel lnameLabel;
	private JLabel phoneNoLabel;
	private JLabel emailLabel;
	private JLabel bdateLabel;
	private JLabel addressLabel;
	private JButton backButton;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					RegisterScreen frame = new RegisterScreen(new JFrame());
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegisterScreen(JFrame parentFrame) {
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 566);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		usernameField = new JTextField();
		usernameField.setBounds(179, 119, 134, 19);
		contentPane.add(usernameField);
		usernameField.setColumns(10);

		passwordField = new JPasswordField();
		passwordField.setBounds(179, 148, 134, 19);
		contentPane.add(passwordField);

		fnameField = new JTextField();
		fnameField.setBounds(179, 177, 134, 19);
		contentPane.add(fnameField);
		fnameField.setColumns(10);

		lnameField = new JTextField();
		lnameField.setBounds(179, 206, 134, 19);
		contentPane.add(lnameField);
		lnameField.setColumns(10);

		phoneNoField = new JTextField();
		phoneNoField.setBounds(179, 235, 134, 19);
		contentPane.add(phoneNoField);
		phoneNoField.setColumns(10);

		emailField = new JTextField();
		emailField.setBounds(179, 264, 134, 19);
		contentPane.add(emailField);
		emailField.setColumns(10);

		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		JFormattedTextField bdateField = new JFormattedTextField(df);
		bdateField.setBounds(179, 293, 134, 18);
		contentPane.add(bdateField);

		addressField = new JTextField();
		addressField.setBounds(179, 321, 134, 19);
		contentPane.add(addressField);
		addressField.setColumns(10);

		JLabel usernameLabel = new JLabel("Kullanıcı Adı");
		usernameLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		usernameLabel.setBounds(35, 119, 134, 19);
		contentPane.add(usernameLabel);

		passwordLabel = new JLabel("Şifre");
		passwordLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		passwordLabel.setBounds(35, 148, 134, 19);
		contentPane.add(passwordLabel);

		fnameLabel = new JLabel("Ad");
		fnameLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		fnameLabel.setBounds(35, 177, 134, 19);
		contentPane.add(fnameLabel);

		lnameLabel = new JLabel("Soyad");
		lnameLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		lnameLabel.setBounds(35, 206, 134, 19);
		contentPane.add(lnameLabel);

		phoneNoLabel = new JLabel("Telefon Numarası");
		phoneNoLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		phoneNoLabel.setBounds(35, 235, 134, 19);
		contentPane.add(phoneNoLabel);

		emailLabel = new JLabel("Eposta");
		emailLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		emailLabel.setBounds(35, 264, 134, 19);
		contentPane.add(emailLabel);

		bdateLabel = new JLabel("Doğum Tarihi");
		bdateLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		bdateLabel.setBounds(35, 292, 134, 19);
		contentPane.add(bdateLabel);

		addressLabel = new JLabel("Adres");
		addressLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		addressLabel.setBounds(35, 324, 134, 19);
		contentPane.add(addressLabel);

		JButton registerButton = new JButton("Üye Ol");
		registerButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String username = usernameField.getText();
				String password = String.valueOf(passwordField.getPassword());
				String fname = fnameField.getText();
				String lname = lnameField.getText();
				String phoneNo = phoneNoField.getText();
				String email = emailField.getText();
				// get date from formatted text field
				String bdate = bdateField.getText();
				String address = addressField.getText();

				// check if not null fields are empty
				if (username.trim().equals("") || password.trim().equals("") || fname.trim().equals("")
						|| lname.trim().equals("") || email.trim().equals("") || bdate.trim().equals("")) {
					JOptionPane.showMessageDialog(registerButton, "Lütfen tüm alanları doldurun!");
					return;
				}

				// check if username already exists
				try {
					Connection connection = DatabaseConnection.getConnection();
					PreparedStatement preparedStatement = connection
							.prepareStatement("SELECT * FROM users WHERE user_name = ?");
					preparedStatement.setString(1, username);
					ResultSet resultSet = preparedStatement.executeQuery();

					if (resultSet.next()) {
						JOptionPane.showMessageDialog(registerButton, "Bu kullanıcı ismi başkası tarafından kullanılıyor!");
						return;
					}

					preparedStatement.close();
					resultSet.close();
				} catch (SQLException ex) {
					ex.printStackTrace();
				}

				// check if email already exists
				try {
					Connection connection = DatabaseConnection.getConnection();
					PreparedStatement preparedStatement = connection
							.prepareStatement("SELECT * FROM users WHERE email = ?");
					preparedStatement.setString(1, email);
					ResultSet resultSet = preparedStatement.executeQuery();

					if (resultSet.next()) {
						JOptionPane.showMessageDialog(registerButton, "Bu eposta başkası tarafından kullanılıyor!");
						return;
					}

					preparedStatement.close();
					resultSet.close();
				} catch (SQLException ex) {
					ex.printStackTrace();
				}

				// check if phone number already exists
				try {
					Connection connection = DatabaseConnection.getConnection();
					PreparedStatement preparedStatement = connection
							.prepareStatement("SELECT * FROM users WHERE phone_no = ?");
					preparedStatement.setString(1, phoneNo);
					ResultSet resultSet = preparedStatement.executeQuery();

					if (resultSet.next()) {
						JOptionPane.showMessageDialog(registerButton, "Bu telefon numarası başkası tarafından kullanılıyor!");
						return;
					}

					preparedStatement.close();
					resultSet.close();
				} catch (SQLException ex) {
					ex.printStackTrace();
				}

				try {
					Connection connection = DatabaseConnection.getConnection();
					PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO users"
							+ "(user_name, hashed_password, first_name, last_name, phone_no, email, bdate, user_address) "
							+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
					preparedStatement.setString(1, username);
					preparedStatement.setString(2, Util.hashPassword(password));
					preparedStatement.setString(3, fname);
					preparedStatement.setString(4, lname);
					preparedStatement.setString(5, phoneNo);
					preparedStatement.setString(6, email);
					// convert bdate string to sql date
					preparedStatement.setDate(7, new java.sql.Date(df.parse(bdate).getTime()));
					preparedStatement.setString(8, address);
					preparedStatement.executeUpdate();

					JOptionPane.showMessageDialog(registerButton, "Kayıt başarılı!");
					parentFrame.setVisible(true);
					preparedStatement.close();
					dispose();
				} catch (SQLException ex) {
					ex.printStackTrace();
				} catch (ParseException e1) {
					e1.printStackTrace();
				}
			}
		});
		registerButton.setBounds(152, 367, 134, 49);
		contentPane.add(registerButton);

		JLabel titleLabel = new JLabel("Üye Kaydı");
		titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		titleLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		titleLabel.setBounds(93, 26, 256, 49);
		contentPane.add(titleLabel);

		backButton = new JButton("Geri Dön");
		backButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				parentFrame.setVisible(true);
				dispose();
			}
		});
		backButton.setBounds(152, 426, 134, 49);
		contentPane.add(backButton);
		
		this.setLocationRelativeTo(null);
	}
}
