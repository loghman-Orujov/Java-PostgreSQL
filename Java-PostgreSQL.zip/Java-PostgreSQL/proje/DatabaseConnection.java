package proje;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private static Connection connection;

    public static Connection getConnection() {
        if (connection == null) {
            try {
                // PostgreSQL veritabanına bağlantı yapılacak bilgiler
                String url = "jdbc:postgresql://localhost:5432/db";
                String username = "postgres";
                String password = "postgres";

                // Bağlantı oluşturma
                connection = DriverManager.getConnection(url, username, password);
                System.out.println("Veritabanına bağlandı.");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return connection;
    }

    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Veritabanı bağlantısı kapatıldı.");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}