package proje;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.text.ParseException;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.text.NumberFormatter;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

public class ProductScreen extends JFrame implements ActionListener {
	private static final long serialVersionUID = 1L;
	private int userId;
	private int selectedCategoryId = -1;
	private JPanel productPanel;
	private JTextField searchField; // Bu satır eklendi

	
	private JLabel userName;
	private JLabel userBalance;
	

	
	
	public ProductScreen(int userId) {

    	System.out.println("launched " + this.getClass());

    	this.addComponentListener(new ComponentAdapter() {

    	    @Override
    	    public void componentShown(ComponentEvent e) {
    	       updateUserBalance();
    	    }
    	});
    	
		this.userId = userId;
		setTitle("Ürünler Ekranı");
		setSize(800, 715);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

		JPanel mainPanel = new JPanel(new BorderLayout());

		JPanel categoryPanel = new JPanel();
		categoryPanel.setLayout(new BoxLayout(categoryPanel, BoxLayout.Y_AXIS));

		JButton allCategoriesButton = new JButton("Tüm Kategoriler");
		allCategoriesButton.addActionListener(e -> {
			selectedCategoryId = -1;
			displayProducts();
		});
		
		
		JPanel balancePanel = new JPanel();
		
		//balancePanel.setLayout(new GridLayout(2, 1));
		
		balancePanel.setLayout(new BoxLayout(balancePanel, BoxLayout.Y_AXIS));

		userName = new JLabel("");
		userBalance = new JLabel("");
		
		balancePanel.add(userName);
//		balancePanel.add(userName,0,0);
		balancePanel.add(userBalance);
//		balancePanel.add(userBalance,0,1);

		
		balancePanel.setBorder(BorderFactory.createCompoundBorder(
				balancePanel.getBorder(), 
		        BorderFactory.createEmptyBorder(10, 15, 10, 0)));
		
		categoryPanel.add(balancePanel);
		

		JButton searchButton = new JButton("Ara");
		searchField = new JTextField();
		searchField.addActionListener( e -> searchButton.doClick());

		//searchField.setBounds(128, 93, 126, 19);




		searchButton.addActionListener(e -> {
			String searchKeyword = searchField.getText();

			searchProducts(searchKeyword);
		});


		JPanel searchPanel = new JPanel();

		//searchPanel.setLayout(new GridLayout(0,2));
		searchPanel.setLayout(new BoxLayout(searchPanel, BoxLayout.Y_AXIS));
		//searchPanel.setBounds(61, 11, 1, 10);
		
		searchPanel.setBorder(BorderFactory.createCompoundBorder(
				searchField.getBorder(),
		        BorderFactory.createEmptyBorder(0, 35, 0, 35)));
		//searchPanel.setMaximumSize(new Dimension(100, 100));
		searchPanel.add(searchField);
		searchPanel.add(searchButton);
		categoryPanel.add(searchPanel);


		categoryPanel.add(allCategoriesButton);
		categoryPanel.add(Box.createRigidArea(new Dimension(0,20)));
		displayCategories(categoryPanel);

		JButton updateUserInfoButton = new JButton("Bilgilerimi Güncelle");
		updateUserInfoButton.addActionListener(e -> {
			updateUserInformation();
		});
		categoryPanel.add(updateUserInfoButton);


		//categoryPanel.add(Box.createRigidArea(new Dimension(0,50)));


		//categoryPanel.add(Box.createRigidArea(new Dimension(20,0)));

		JButton boughtItemsButton = new JButton("Satın Alınan Ürünler");
		boughtItemsButton.addActionListener(e -> {
			BoughtItemsScreen boughtItemsScreen = new BoughtItemsScreen(ProductScreen.this, userId);
			boughtItemsScreen.setVisible(true);
			setVisible(false);
		});
		categoryPanel.add(boughtItemsButton);
		JButton addProductButton = new JButton("Yeni Ürün Ekle");
		addProductButton.addActionListener(e -> {
			addNewProduct();
		});
		categoryPanel.add(addProductButton);

		JButton increaseBalanceButton = new JButton("Bakiye Artır");
		increaseBalanceButton.addActionListener(e -> {
			increaseBalance();
		});
		categoryPanel.add(increaseBalanceButton);


		JButton topButton = new JButton("Top Products");
		topButton.addActionListener(e -> {

			showTop();

		});
		categoryPanel.add(topButton);


		JButton logoutButton = new JButton("Çıkış Yap");
		logoutButton.addActionListener(e -> {
			LoginScreen loginScreen = new LoginScreen();
			loginScreen.setVisible(true);
			dispose();
		});

		JButton deleteAccountButton = new JButton("Hesabı Sil");
		deleteAccountButton.addActionListener(e -> {
			int value =JOptionPane.showConfirmDialog(ProductScreen.this, "Hesabınızı silmek istediğinize emin misiniz?");
			if(value == 0 && deleteAccount() > 0) {
				LoginScreen loginScreen = new LoginScreen();
				loginScreen.setVisible(true);
				dispose();
			}
		});
		categoryPanel.add(deleteAccountButton);
		categoryPanel.add(logoutButton);

		mainPanel.add(categoryPanel, BorderLayout.WEST);

		productPanel = new JPanel();
		productPanel.setLayout(new GridLayout(0, 3));

		JScrollPane scrollPane = new JScrollPane(productPanel);
		mainPanel.add(scrollPane, BorderLayout.CENTER);

		getContentPane().add(mainPanel);
		displayProducts();
		updateUserBalance();
        this.setLocationRelativeTo(null);
        this.pack();
		setSize(800, getSize().height);
	}

	
	private void updateUserBalance() {
		
		
        try {
        	
            Connection connection = DatabaseConnection.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(
            		"select user_name,balance from users where user_id = ?");
            preparedStatement.setInt(1, userId);
            
            
            boolean hasResultSet = preparedStatement.execute();

			if (hasResultSet) {
				ResultSet resultSet = preparedStatement.getResultSet();

				while (resultSet.next()) {
					String itemName = resultSet.getString("user_name");
					String itemBalance = resultSet.getString("balance");

					
					userName.setText(itemName);
					userBalance.setText(itemBalance+" TL");

				}

				resultSet.close();
			}

			preparedStatement.close();
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        
		
		
	}
	
	
	private int deleteAccount() {
        int deleted= 0;
        try {
            Connection connection = DatabaseConnection.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(
            		"DELETE FROM users WHERE user_id = ?");
            preparedStatement.setInt(1, userId);
            deleted = preparedStatement.executeUpdate();
            System.out.println(deleted);
            if (deleted > 0) {
                JOptionPane.showMessageDialog(this, "Hesabınız başarıyla silindi!");
            } else {
                JOptionPane.showMessageDialog(this, "Hesabınız silinirken bir hata oluştu.");
            }
            preparedStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return deleted;
}


	private void showTop() {

		productPanel.removeAll();

		try {
			Connection connection = DatabaseConnection.getConnection();
			PreparedStatement preparedStatement;

			preparedStatement = connection.prepareStatement(
				"SELECT * FROM available_items av_i WHERE av_i.item_id IN ( " +
				"SELECT o.item_id " +
				"FROM orders o " +
				"GROUP BY o.item_id " +
				"HAVING SUM(o.amount) > 10 "
				+ "ORDER BY SUM(o.amount) DESC "
				+ "LIMIT 10" +
				")"
			);

			boolean hasResultSet = preparedStatement.execute();

			if (hasResultSet) {
				ResultSet resultSet = preparedStatement.getResultSet();

				while (resultSet.next()) {
					int itemId = resultSet.getInt("item_id");
					String itemName = resultSet.getString("item_name");
					String itemDescription = resultSet.getString("item_description");
					String price = resultSet.getString("price");
					String amount = resultSet.getString("item_count");
					String categoryName = resultSet.getString("category_name");
					String sellerName = resultSet.getString("seller_name");

					JPanel itemPanel = getItemPanel(itemId, itemName, itemDescription, price, amount, categoryName,
							sellerName);

					productPanel.add(itemPanel);
				}

				resultSet.close();
			}

			preparedStatement.close();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

		revalidate();
		repaint();



	}
	private void searchProducts(String keyword) {
		productPanel.removeAll();

		try {
			Connection connection = DatabaseConnection.getConnection();
			PreparedStatement preparedStatement;

			if (selectedCategoryId != -1) {
				preparedStatement = connection
						.prepareStatement("SELECT * FROM available_items WHERE category_id = ? AND item_name ILIKE ?");
				preparedStatement.setInt(1, selectedCategoryId);
				preparedStatement.setString(2, "%" + keyword + "%");
			} else {
				preparedStatement = connection
						.prepareStatement("SELECT * FROM available_items WHERE item_name ILIKE ?");
				preparedStatement.setString(1, "%" + keyword + "%");
			}

			boolean hasResultSet = preparedStatement.execute();

			if (hasResultSet) {
				ResultSet resultSet = preparedStatement.getResultSet();

				while (resultSet.next()) {
					int itemId = resultSet.getInt("item_id");
					String itemName = resultSet.getString("item_name");
					String itemDescription = resultSet.getString("item_description");
					String price = resultSet.getString("price");
					String amount = resultSet.getString("item_count");
					String categoryName = resultSet.getString("category_name");
					String sellerName = resultSet.getString("seller_name");

					JPanel itemPanel = getItemPanel(itemId, itemName, itemDescription, price, amount, categoryName,
							sellerName);

					productPanel.add(itemPanel);
				}

				resultSet.close();
			}

			preparedStatement.close();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

		revalidate();
		repaint();
	}

	private void displayCategories(JPanel categoryPanel) {
		try {
			Connection connection = DatabaseConnection.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM category");
			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				int categoryId = resultSet.getInt("category_id");
				String categoryName = resultSet.getString("category_name");

				JButton categoryButton = new JButton(categoryName);
				categoryButton.addActionListener(e -> {
					selectedCategoryId = categoryId;
					displayProducts();
				});

				categoryPanel.add(categoryButton);
			}

			preparedStatement.close();
			resultSet.close();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	private JPanel getItemPanel(int itemId, String itemName, String itemDescription, String price, String amount, String categoryName, String sellerName) {
        JPanel itemPanel = new JPanel();
        itemPanel.setLayout(new BoxLayout(itemPanel, BoxLayout.Y_AXIS));

        JLabel nameLabel = new JLabel(itemName);
        nameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        itemPanel.add(nameLabel);

        JLabel descriptionLabel = new JLabel(itemDescription);
        descriptionLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        itemPanel.add(descriptionLabel);

        JLabel priceLabel = new JLabel("Price: " + price);
        priceLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        itemPanel.add(priceLabel);

        JLabel amountLabel = new JLabel("Amount: " + amount);
        amountLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        itemPanel.add(amountLabel);

        JLabel categoryLabel = new JLabel("Category: " + categoryName);
        categoryLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        itemPanel.add(categoryLabel);

        JLabel sellerLabel = new JLabel("Seller: " + sellerName);
        sellerLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        itemPanel.add(sellerLabel);

        JButton viewButton = new JButton("İncele");
        viewButton.setFont(new Font("Arial", Font.PLAIN, 10));
        viewButton.addActionListener(e -> {
            ProductDetailsScreen detailsScreen = new ProductDetailsScreen(itemId);
            detailsScreen.setVisible(true);
        });

        JButton buyButton = new JButton("Satın Al");
        buyButton.setFont(new Font("Arial", Font.PLAIN, 10));
        buyButton.addActionListener(e -> {
            buyItem(itemId);
        });

        itemPanel.add(viewButton);
        itemPanel.add(buyButton);

        return itemPanel;
    }

	private void displayProducts() {
		productPanel.removeAll();

		try {
			Connection connection = DatabaseConnection.getConnection();
			PreparedStatement preparedStatement;
			if (selectedCategoryId != -1) {
				preparedStatement = connection.prepareStatement("SELECT * FROM available_items WHERE category_id = ?");
				preparedStatement.setInt(1, selectedCategoryId);
			} else {
				preparedStatement = connection.prepareStatement("SELECT * FROM available_items");
			}

			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				int itemId = resultSet.getInt("item_id");
				String itemName = resultSet.getString("item_name");
				String itemDescription = resultSet.getString("item_description");
				String price = resultSet.getString("price");
				String amount = resultSet.getString("item_count");
				String categoryName = resultSet.getString("category_name");
				String sellerName = resultSet.getString("seller_name");

				JPanel itemPanel = getItemPanel(itemId, itemName, itemDescription, price, amount, categoryName, sellerName);

				productPanel.add(itemPanel);
			}

			preparedStatement.close();
			resultSet.close();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

		revalidate();
		repaint();
	}

	private void buyItem(int itemId) {
		String input;

		do {
			input = JOptionPane.showInputDialog("Kaç adet ürün almak istersiniz?");

			// hit cancel
			if (input == null) {
				return;
			}

			// no input string
			if (input.isEmpty()) {
				JOptionPane.showMessageDialog(productPanel, "Lütfen bir değer giriniz.");
			}
		} while (input.isEmpty());

		Integer amount;
		try {
			amount = Integer.parseInt(input);
		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(productPanel, "Geçersiz değer girdiniz.");
			return;
		}

		try {
			Connection connection = DatabaseConnection.getConnection();
			// buy the item using buyItem stored procedure
			PreparedStatement preparedStatement = connection.prepareStatement("SELECT buy_item(?, ?, ?)");
			preparedStatement.setInt(1, userId);
			preparedStatement.setInt(2, itemId);
			preparedStatement.setInt(3, amount);
			ResultSet resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				JOptionPane.showMessageDialog(this, "Ürün başarıyla satın alındı!");
				displayProducts();
			} else {
				JOptionPane.showMessageDialog(this, "Ürün satın alınırken bir hata oluştu.");
			}

		} catch (SQLException ex) {
			JOptionPane.showMessageDialog(this, "Ürün satın alınırken bir hata oluştu: " + ex.getMessage());
//            ex.printStackTrace();
		}
		
		updateUserBalance();

	}


	private void addNewProduct() {
		JFrame frame = new JFrame("Yeni Ürün Ekleme Ekranı");
		frame.setSize(400, 300);
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(6, 2));

		JLabel nameLabel = new JLabel("Ürün Adı:");
		JTextField nameField = new JTextField();

		JLabel descriptionLabel = new JLabel("Ürün Açıklaması:");
		JTextField descriptionField = new JTextField();

		JLabel priceLabel = new JLabel("Ürün Fiyatı:");
		JTextField priceField = new JTextField();

		JLabel countLabel = new JLabel("Ürün Adedi:");
		JTextField countField = new JTextField();

		JLabel categoryLabel = new JLabel("Kategori:");
		JComboBox<String> categoryComboBox = new JComboBox<>();

		// get categories from database
		try {
			Connection connection = DatabaseConnection.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM category");
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				String categoryName = resultSet.getString("category_name");
				categoryComboBox.addItem(categoryName);
			}
			preparedStatement.close();
			resultSet.close();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

		JButton addButton = new JButton("Ekle");
		addButton.addActionListener(e -> {
			String itemName = nameField.getText();
			String itemDescription = descriptionField.getText();
			String priceText = priceField.getText();
			String countText = countField.getText();
			String categoryName = (String) categoryComboBox.getSelectedItem();

			if (!itemName.isEmpty() && !priceText.isEmpty() && !countText.isEmpty() && !categoryName.isEmpty()) {
				try {
					double price = Double.parseDouble(priceText);
					int count = Integer.parseInt(countText);
					int categoryID;

					Connection connection = DatabaseConnection.getConnection();
					// get category ID from database
					PreparedStatement preparedStatement = connection
							.prepareStatement("SELECT * FROM category WHERE category_name = ?");
					preparedStatement.setString(1, categoryName);
					ResultSet resultSet = preparedStatement.executeQuery();
					if (resultSet.next()) {
						categoryID = resultSet.getInt("category_id");
					} else {
						JOptionPane.showMessageDialog(frame, "Geçersiz kategori adı girildi.");
						return;
					}
					preparedStatement.close();
					resultSet.close();

					preparedStatement = connection.prepareStatement(
							"INSERT INTO items (seller_id, item_name, item_description, price, item_count, category_id) VALUES (?, ?, ?, ?, ?, ?)");
					preparedStatement.setInt(1, userId);
					preparedStatement.setString(2, itemName);
					preparedStatement.setString(3, itemDescription);
					preparedStatement.setDouble(4, price);
					preparedStatement.setInt(5, count);
					preparedStatement.setInt(6, categoryID);

					int inserted = preparedStatement.executeUpdate();
					if (inserted > 0) {
						JOptionPane.showMessageDialog(frame, "Yeni ürün başarıyla eklendi!");
						displayProducts();
						frame.dispose();
					} else {
						JOptionPane.showMessageDialog(frame, "Ürün eklenirken bir hata oluştu.");
					}

					preparedStatement.close();
				} catch (NumberFormatException | SQLException ex) {
					ex.printStackTrace();
					JOptionPane.showMessageDialog(frame, "Geçersiz fiyat, adet veya kategori ID'si girildi.");
				}
			} else {
				JOptionPane.showMessageDialog(frame, "Lütfen tüm alanları doldurun.");
			}
		});

		panel.add(nameLabel);
		panel.add(nameField);
		panel.add(descriptionLabel);
		panel.add(descriptionField);
		panel.add(priceLabel);
		panel.add(priceField);
		panel.add(countLabel);
		panel.add(countField);
		panel.add(categoryLabel);
		panel.add(categoryComboBox);
		panel.add(addButton);


		panel.setBorder(BorderFactory.createCompoundBorder(
        		panel.getBorder(),
		        BorderFactory.createEmptyBorder(10, 25, 25, 25)));


		frame.getContentPane().add(panel);
		frame.setLocationRelativeTo(null);

		frame.setVisible(true);


	}

	private void updateUserInformation() {
		JFrame frame = new JFrame("Bilgi Güncelleme Ekranı");
		frame.setSize(400, 300);
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(6, 2));

		JLabel usernameLabel = new JLabel("Kullanıcı Adı:");
		JTextField newUsernameField = new JTextField();
		
		JLabel passwordLabel = new JLabel("Şifre:");
		JPasswordField newPasswordField = new JPasswordField();

		JLabel phoneLabel = new JLabel("Telefon Numarası:");
		JTextField newPhoneField = new JTextField();

		JLabel emailLabel = new JLabel("E-posta:");
		JTextField newEmailField = new JTextField();

		JLabel addressLabel = new JLabel("Adres:");
		JTextField newAddressField = new JTextField();
		

		// Retrieve original values from the database
		try {
			Connection connection = DatabaseConnection.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(
					"SELECT user_name, phone_no, email, user_address FROM users WHERE user_id = ?");
			preparedStatement.setInt(1, userId);
			ResultSet resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				// Initialize text fields with the retrieved values
				newUsernameField.setText(resultSet.getString("user_name"));
				newPhoneField.setText(resultSet.getString("phone_no"));
				newEmailField.setText(resultSet.getString("email"));
				newAddressField.setText(resultSet.getString("user_address"));
			}

			resultSet.close();
			preparedStatement.close();
			connection.close();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}


		JButton updateButton = new JButton("Güncelle");
		updateButton.addActionListener(e -> {
			String newUsername = newUsernameField.getText();
			String newPassword = String.valueOf(newPasswordField.getPassword());
			String newPhone = newPhoneField.getText();
			String newEmail = newEmailField.getText();
			String newAddress = newAddressField.getText();


			if (!newUsername.isEmpty() || !newPassword.isEmpty() || !newPhone.isEmpty() || !newEmail.isEmpty() || !newAddress.isEmpty()) {
				try {
					Connection connection = DatabaseConnection.getConnection();
					PreparedStatement preparedStatement = connection.prepareStatement(
							"UPDATE users SET user_name = COALESCE(?, user_name), hashed_password = COALESCE(?, hashed_password), phone_no = COALESCE(?, phone_no), email = COALESCE(?, email), user_address = COALESCE(?, user_address) WHERE user_id = ?");
					preparedStatement.setString(1, newUsername.isEmpty() ? null : newUsername);
					preparedStatement.setString(2, newPassword.isEmpty() ? null : newPassword);
					preparedStatement.setString(3, newPhone.isEmpty() ? null : newPhone);
					preparedStatement.setString(4, newEmail.isEmpty() ? null : newEmail);
					preparedStatement.setString(5, newAddress.isEmpty() ? null : newAddress);
					preparedStatement.setInt(6, userId);

					int updated = preparedStatement.executeUpdate();
					if (updated > 0) {
						JOptionPane.showMessageDialog(frame, "Bilgileriniz güncellendi!");
					} else {
						JOptionPane.showMessageDialog(frame, "Bilgileriniz güncellenirken bir hata oluştu.");
					}

					preparedStatement.close();
				} catch (SQLException ex) {
					ex.printStackTrace();
				}
			} else {
				JOptionPane.showMessageDialog(frame, "En az bir alanı doldurunuz.");
			}

			/*
			panel.setBorder(BorderFactory.createCompoundBorder(
					searchField.getBorder(),
			        BorderFactory.createEmptyBorder(35, 35, 35, 35)));
			*/
		});

		panel.add(usernameLabel);
		panel.add(newUsernameField);
		panel.add(passwordLabel);
		panel.add(newPasswordField);
		panel.add(phoneLabel);
		panel.add(newPhoneField);
		panel.add(emailLabel);
		panel.add(newEmailField);
		panel.add(addressLabel);
		panel.add(newAddressField);
		panel.add(updateButton);

		panel.setBorder(BorderFactory.createCompoundBorder(
				searchField.getBorder(),
		        BorderFactory.createEmptyBorder(25, 25, 25, 25)));
		frame.getContentPane().add(panel);
		frame.setLocationRelativeTo(null);

		frame.setVisible(true);
	}



	private void increaseBalance() {
		JFrame frame = new JFrame("Bakiye Artirma Ekrani");
		frame.setSize(200, 200);
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(5, 2));

		JLabel amountLabel = new JLabel("Girilecek miktar:");
		// create a number formatter to only allow numbers
		NumberFormat numberFormat = NumberFormat.getNumberInstance();
		NumberFormatter numberFormatter = new NumberFormatter(numberFormat);
		numberFormatter.setValueClass(Double.class);
		numberFormatter.setAllowsInvalid(false);
		numberFormatter.setMinimum(0.0);

		JFormattedTextField amountField = new JFormattedTextField(numberFormatter);

		JButton updateButton = new JButton("Güncelle");
		updateButton.addActionListener(e -> {
			// get amount from amountField
			String amountText = amountField.getText();

			if (!amountText.isEmpty()) {
				try {
					double amount = (double) numberFormatter.stringToValue(amountText);

					Connection connection = DatabaseConnection.getConnection();
					PreparedStatement preparedStatement = connection
							.prepareStatement("UPDATE users SET balance = balance + ? WHERE user_id = ?");
					preparedStatement.setDouble(1, amount);
					preparedStatement.setInt(2, userId);

					int updated = preparedStatement.executeUpdate();
					if (updated > 0) {
						JOptionPane.showMessageDialog(frame, "Bakiyeniz güncellendi!");
						updateUserBalance();
						frame.dispose();
					} else {
						JOptionPane.showMessageDialog(frame, "Bakiyeniz güncellenirken bir hata oluştu.");
					}

					preparedStatement.close();
				} catch (SQLException | ParseException ex) {
					JOptionPane.showMessageDialog(frame,
							"Bakiyeniz güncellenirken bir hata oluştu: " + ex.getMessage());
				}
			} else {
				JOptionPane.showMessageDialog(frame, "En az bir alanı doldurunuz.");
			}
		});

		panel.add(amountLabel);
		panel.add(amountField);
		panel.add(updateButton);

		frame.getContentPane().add(panel);
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
	}
}
