package proje;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class BoughtItemsScreen extends JFrame implements ActionListener {
    private static final long serialVersionUID = 1L;
    private int userId;
    private JPanel productPanel;
    private JTextField searchField; // Bu satır eklendi

    public BoughtItemsScreen(JFrame parentFrame, int userId) {
        this.userId = userId;
        setTitle("Satın Alınan Ürünler");
        setSize(800, 600);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());

        JPanel categoryPanel = new JPanel();
        categoryPanel.setLayout(new BoxLayout(categoryPanel, BoxLayout.Y_AXIS));

        JButton searchButton = new JButton("Ara");
        searchField = new JTextField();
        searchButton.addActionListener(e -> {
            String searchKeyword = searchField.getText();
            searchProducts(searchKeyword);
        });
        JPanel searchPanel = new JPanel();
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        categoryPanel.add(searchPanel);

        JButton boughtItemsButton = new JButton("Geri Dön");
        boughtItemsButton.addActionListener(e -> {
            parentFrame.setVisible(true);
            dispose();
        });
        categoryPanel.add(boughtItemsButton);

        mainPanel.add(categoryPanel, BorderLayout.WEST);

        productPanel = new JPanel();
        productPanel.setLayout(new GridLayout(0, 3));

        JScrollPane scrollPane = new JScrollPane(productPanel);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        getContentPane().add(mainPanel);
        displayProducts();
    }

    private void searchProducts(String keyword) {
        productPanel.removeAll();

        try {
            Connection connection = DatabaseConnection.getConnection();
            PreparedStatement preparedStatement;

            preparedStatement = connection.prepareStatement(
                    "SELECT * FROM get_bought_items(?) WHERE item_name ILIKE ?");
            preparedStatement.setInt(1, userId);
            preparedStatement.setString(2, "%" + keyword + "%");

            boolean hasResultSet = preparedStatement.execute();

            if (hasResultSet) {
                ResultSet resultSet = preparedStatement.getResultSet();

                while (resultSet.next()) {
                    int itemId = resultSet.getInt("item_id");
                    String itemName = resultSet.getString("item_name");
                    String itemDescription = resultSet.getString("item_description");
                    String price = resultSet.getString("price");
                    String amount = resultSet.getString("amount");
                    String categoryName = resultSet.getString("category_name");
                    String sellerName = resultSet.getString("seller_name");
                    LocalDateTime purchaseDateTime = resultSet.getTimestamp("purchase_date").toLocalDateTime();
                    LocalDate purchaseDate = purchaseDateTime.toLocalDate();

                    JPanel itemPanel = getItemPanel(itemId, itemName, itemDescription, price, amount, categoryName, sellerName, purchaseDate.format(DateTimeFormatter.ISO_DATE));

                    productPanel.add(itemPanel);
                }

                resultSet.close();
            }

            preparedStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        revalidate();
        repaint();
    }

    private JPanel getItemPanel(int itemId, String itemName, String itemDescription, String price, String amount, String categoryName, String sellerName, String purchaseDate) {
        JPanel itemPanel = new JPanel();
        itemPanel.setLayout(new BoxLayout(itemPanel, BoxLayout.Y_AXIS));

        JLabel nameLabel = new JLabel(itemName);
        nameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        itemPanel.add(nameLabel);

        JLabel descriptionLabel = new JLabel(itemDescription);
        descriptionLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        itemPanel.add(descriptionLabel);

        JLabel priceLabel = new JLabel("Price: " + price);
        priceLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        itemPanel.add(priceLabel);

        JLabel amountLabel = new JLabel("Amount: " + amount);
        amountLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        itemPanel.add(amountLabel);

        JLabel categoryLabel = new JLabel("Category: " + categoryName);
        categoryLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        itemPanel.add(categoryLabel);

        JLabel sellerLabel = new JLabel("Seller: " + sellerName);
        sellerLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        itemPanel.add(sellerLabel);

        JLabel purchaseDateLabel = new JLabel("Purchase Date: " + purchaseDate);
        purchaseDateLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        itemPanel.add(purchaseDateLabel);

        JButton viewButton = new JButton("İncele");
        viewButton.setFont(new Font("Arial", Font.PLAIN, 10));
        viewButton.addActionListener(e -> {
            ProductDetailsScreen detailsScreen = new ProductDetailsScreen(itemId);
            detailsScreen.setVisible(true);
        });

        JButton buyButton = new JButton("Satın Al");
        buyButton.setFont(new Font("Arial", Font.PLAIN, 10));
        buyButton.addActionListener(e -> {
            buyItem(itemId);
        });

        itemPanel.add(viewButton);
        itemPanel.add(buyButton);

        return itemPanel;
    }
    private void displayProducts() {
        productPanel.removeAll();

        try {
            Connection connection = DatabaseConnection.getConnection();
            PreparedStatement preparedStatement;
            preparedStatement = connection.prepareStatement(
                    "SELECT * FROM get_bought_items(?)");
            preparedStatement.setInt(1, userId);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int itemId = resultSet.getInt(3);
                String itemName = resultSet.getString(4);
                String itemDescription = resultSet.getString("item_description");
                String price = resultSet.getString("price");
                String amount = resultSet.getString("amount");
                String categoryName = resultSet.getString("category_name");
                String sellerName = resultSet.getString("seller_name");
                LocalDateTime purchaseDateTime = resultSet.getTimestamp("purchase_date").toLocalDateTime();
                LocalDate purchaseDate = purchaseDateTime.toLocalDate();

                JPanel itemPanel = getItemPanel(itemId, itemName, itemDescription, price, amount, categoryName, sellerName, purchaseDate.format(DateTimeFormatter.ISO_DATE));

                productPanel.add(itemPanel);
            }

            preparedStatement.close();
            resultSet.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
		this.setLocationRelativeTo(null);

        revalidate();
        repaint();
    }

    private void buyItem(int itemId) {
    	String input;
    	


		do {
			input = JOptionPane.showInputDialog("Kaç adet ürün almak istersiniz?");

			// hit cancel
			if (input == null) {
				return;
			}

			// no input string
			if (input.isEmpty()) {
				JOptionPane.showMessageDialog(productPanel, "Lütfen bir değer giriniz.");
			}
		} while (input.isEmpty());

		System.out.println(input);

		Integer amount;
		try {
			amount = Integer.parseInt(input);
		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(productPanel, "Geçersiz değer girdiniz.");
			return;
		}

		try {
			Connection connection = DatabaseConnection.getConnection();
			// buy the item using buyItem stored procedure
			PreparedStatement preparedStatement = connection.prepareStatement("SELECT buy_item(?, ?, ?)");
			preparedStatement.setInt(1, userId);
			preparedStatement.setInt(2, itemId);
			preparedStatement.setInt(3, amount);
			ResultSet resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				JOptionPane.showMessageDialog(this, "Ürün başarıyla satın alındı!");
				displayProducts();
			} else {
				JOptionPane.showMessageDialog(this, "Ürün satın alınırken bir hata oluştu.");
			}

		} catch (SQLException ex) {
			JOptionPane.showMessageDialog(this, "Ürün satın alınırken bir hata oluştu: " + ex.getMessage());
//            ex.printStackTrace();
		}
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    }
}
