package proje;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;

public class LoginScreen extends JFrame implements ActionListener {
    /**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton btnNewButton;
    private JLabel lblNewLabel;

    public LoginScreen() {
    	setResizable(false);
        setTitle("Giriş Ekranı");
        setSize(344, 400);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 386, 363);
        JLabel usernameLabel = new JLabel("Kullanıcı Adı:");
        usernameLabel.setHorizontalAlignment(SwingConstants.TRAILING);
        usernameLabel.setBounds(27, 96, 91, 13);
        JLabel passwordLabel = new JLabel("Şifre:");
        passwordLabel.setHorizontalAlignment(SwingConstants.TRAILING);
        passwordLabel.setBounds(59, 125, 59, 13);

        usernameField = new JTextField(15);
        usernameField.setBounds(128, 93, 126, 19);
        passwordField = new JPasswordField(15);
        passwordField.setBounds(128, 122, 126, 19);

        loginButton = new JButton("Giriş Yap");
        loginButton.setBounds(118, 198, 97, 31);
        loginButton.addActionListener(this);
        getContentPane().setLayout(null);
        panel.setLayout(null);

        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(loginButton);

        getContentPane().add(panel);

        btnNewButton = new JButton("Üye Ol");
        btnNewButton.addActionListener(new ActionListener() {
        	@Override
			public void actionPerformed(ActionEvent e) {
        		RegisterScreen registerScreen = new RegisterScreen(LoginScreen.this);
        		registerScreen.setVisible(true);
                setVisible(false); // LoginScreen'i gizle
        	}
        });
        btnNewButton.setBounds(118, 239, 97, 31);
        panel.add(btnNewButton);

        lblNewLabel = new JLabel("Üye Girişi");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setBounds(59, 24, 223, 31);
        panel.add(lblNewLabel);
        getRootPane().setDefaultButton(loginButton);
        this.setLocationRelativeTo(null);


    }

    @Override
	public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginButton) {
            String username = usernameField.getText();
            String password = String.valueOf(passwordField.getPassword());

            try {
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM users WHERE user_name = ? AND hashed_password = ?");
                preparedStatement.setString(1, username);
                preparedStatement.setString(2, Util.hashPassword(password));
                ResultSet resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    int userId = resultSet.getInt("user_id");
                    JOptionPane.showMessageDialog(this, "Giriş başarılı!");

                    ProductScreen productScreen = new ProductScreen(userId);
                    productScreen.setVisible(true);
                    setVisible(false); // LoginScreen'i gizle
                } else {
                    JOptionPane.showMessageDialog(this, "Geçersiz kullanıcı adı veya şifre!");
                }

                preparedStatement.close();
                resultSet.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

    }


}