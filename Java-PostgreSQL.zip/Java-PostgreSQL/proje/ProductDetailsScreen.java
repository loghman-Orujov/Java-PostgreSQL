package proje;

import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

public class ProductDetailsScreen extends JFrame {
    /**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public ProductDetailsScreen(int itemId) {

    	System.out.println("launched " + this.getClass());

        setTitle("Ürün Detayları");
        setSize(500, 200);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE); // Sadece bu ekranı kapatır, ana ekranı kapatmaz
        JLabel priceLabel = new JLabel("Fiyat: ");
        JLabel countLabel = new JLabel("Stokta: ");
        JLabel soldAmountLabel = new JLabel("Toplam Satılan Miktar: ");
        JPanel panel = new JPanel();
        //FlowLayout flowLayout = (FlowLayout) panel.getLayout();
        panel.setLayout(new GridLayout(3, 2));


        panel.setBorder(BorderFactory.createCompoundBorder(
        		panel.getBorder(),
		        BorderFactory.createEmptyBorder(10, 25, 25, 25)));


        //flowLayout.setAlignOnBaseline(true);
        panel.add(priceLabel,0,0);
        panel.add(countLabel,0,1);
        panel.add(soldAmountLabel,1,0);
        getContentPane().add(panel);

        JLabel nameLabel = new JLabel("Ürün Adı: ");
        panel.add(nameLabel,1,1);
        JLabel descriptionLabel = new JLabel("Açıklama: ");
        panel.add(descriptionLabel,2,0);

        //this.pack();
        this.setLocationRelativeTo(null);

        // get the item details from the database
        try {
            Connection connection = DatabaseConnection.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "SELECT * FROM detailed_items WHERE item_id = ?"
            );
            preparedStatement.setInt(1, itemId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                String itemName = resultSet.getString("item_name");
                String itemDescription = resultSet.getString("item_description");
                double price = resultSet.getDouble("price");
                int count = resultSet.getInt("item_count");

                // update the panel
                nameLabel.setText(nameLabel.getText() + itemName);
                descriptionLabel.setText(descriptionLabel.getText() + itemDescription);
                priceLabel.setText(priceLabel.getText() + price);
                countLabel.setText(countLabel.getText() + count);
            }

            preparedStatement.close();
            resultSet.close();

            preparedStatement = connection.prepareStatement(
                    "SELECT get_sold_amount(?)"
            );
            preparedStatement.setInt(1, itemId);
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                Integer soldAmount = resultSet.getInt(1);

                soldAmountLabel.setText(soldAmountLabel.getText() + soldAmount.toString());
            }
            preparedStatement.close();
            resultSet.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
