------ Seqeunces ------
create sequence user_id_seq start 1; -- Sequence to generate unique user ids
create sequence order_id_seq start 1; -- Sequence to generate unique order ids
create sequence item_id_seq start 1; -- Sequence to generate unique item ids
create sequence category_id_seq start 1; -- Sequence to generate unique category ids


------ Tables ------
-- Table to store user information
create table users (
    user_id int primary key default nextval('user_id_seq'), -- unique identifier for each user
    user_name VARCHAR(25) NOT NULL UNIQUE, -- Username with a maximum length of 25 characters, must be unique
    hashed_password CHAR(64) NOT NULL, -- Hashed password for security
    first_name VARCHAR(30) NOT NULL, -- User's first name
    last_name VARCHAR(30) NOT NULL, -- User's last name
    phone_no VARCHAR(20), -- User's phone number
    email VARCHAR(256) NOT NULL UNIQUE, -- User's email address, must be unique
    bdate DATE NOT NULL, -- User's birth date
    user_address VARCHAR, -- User's address
    balance DECIMAL(12, 2) NOT NULL CHECK(balance >= 0) DEFAULT 0 -- User's balance with a minimum value of 0
);
ALTER SEQUENCE user_id_seq OWNED BY users.user_id; -- Set the sequence to be owned by the user_id column

-- Table to store item categories
create table category(
    category_id INT PRIMARY KEY DEFAULT nextval('category_id_seq'), -- Unique identifier for each category
    category_name VARCHAR(70) NOT NULL UNIQUE -- Category name with a maximum length of 70 characters, must be unique
);
ALTER SEQUENCE category_id_seq OWNED BY category.category_id; -- Set the sequence to be owned by the category_id column

-- Table to store information about items for sale
create table items(
    item_id INT PRIMARY KEY DEFAULT nextval('item_id_seq'), -- Unique identifier for each item
    seller_id INT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE, -- Foreign key referencing the user who is selling the item
    item_name VARCHAR NOT NULL, -- Name of the item
    item_description VARCHAR, -- Description of the item
    price DECIMAL(12, 2) NOT NULL CHECK(price >= 0), -- Price of the item with a minimum value of 0
    item_count INT DEFAULT 0 CHECK(item_count >= 0), -- Number of items available for sale with a minimum value of 0
    category_id INT NOT NULL REFERENCES category -- Foreign key referencing the category of the item
);
ALTER SEQUENCE item_id_seq OWNED BY items.item_id; -- Set the sequence to be owned by the item_id column

-- Table to store the relationship between orders and items
create table orders(
    order_id INT NOT NULL PRIMARY KEY DEFAULT nextval('order_id_seq'), -- Unique identifier for each order
    item_id INT NOT NULL REFERENCES items ON DELETE CASCADE, -- Foreign key referencing the item in the order
    user_id INT NOT NULL REFERENCES users ON DELETE CASCADE, -- Foreign key referencing the user who placed the order
    amount INT NOT NULL CHECK(amount > 0), -- Amount of the item in the order, must be greater than 0
    purchase_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP -- Timestamp of when the order was placed
);
ALTER SEQUENCE order_id_seq OWNED BY orders.order_id; -- Set the sequence to be owned by the order_id column

------ Views ------
create view sellers as -- View to get the list of sellers
select distinct user_id, users.user_name as seller_name
from users, items
where users.user_id = items.seller_id;

create view detailed_items as -- View to get the list of items with details
select items.item_id, items.item_name, items.item_description, items.price, items.item_count, category.category_id, category.category_name, seller_id, seller_name
from items, category, sellers
where items.category_id = category.category_id and items.seller_id = sellers.user_id;

create view available_items as -- View to get the list of available items (items with count > 0)
select * from detailed_items
where item_count > 0;

create view detailed_orders as -- View to get the list of orders with details
select orders.order_id order_id, orders.user_id user_id, items.item_id item_id, items.item_name item_name, item_description, items.price price, orders.amount as amount, (price*amount) total_spent, category_name, seller_id, seller_name, purchase_date
from orders, items, category, sellers
where orders.item_id = items.item_id and items.category_id = category.category_id and items.seller_id = sellers.user_id;

-- a view to get information about how many of each item was sold and how much money was made from each item
create view sales_report as
select item_name, sum(amount) as total_sold, sum(amount * price) as total_revenue
from detailed_orders
group by item_name;


------ Triggers ------
create or replace function check_balance_count_func() returns trigger as -- Function to check if the user has enough balance to place an order and if there are enough items available
$$
begin
    if (select balance from users where user_id = new.user_id) < (select price from items where item_id = new.item_id) * new.amount then
        raise exception 'Insufficient balance';
    elsif (select item_count from items where item_id = new.item_id) < new.amount then
        raise exception 'Insufficient items';
    end if;
    return new;
end;
$$ language 'plpgsql';

create or replace trigger check_balance_count -- Trigger to check if the user has enough balance to place an order and if there are enough items available
before insert on orders
for each row execute procedure check_balance_count_func();

create or replace function check_seller_func() returns trigger as -- Function to check if the user is trying to buy their own item
$$
begin
    if (select seller_id from items where item_id = new.item_id) = new.user_id then
        raise exception 'You cannot buy your own item';
    end if;
    return new;
end;
$$ language 'plpgsql';

create or replace trigger check_seller -- Trigger to check if the user is trying to buy their own item
before insert on orders
for each row execute procedure check_seller_func();

------ Functions ------
-- function to atomically buy an item and update the balance of the involved users and the count of the item
create or replace function buy_item(user_id_param users.user_id%type, item_id_param items.item_id%type, amount_param orders.amount%type) returns void as
$$
declare
    seller_id_ users.user_id%type;
    item_price items.price%type;
    seller_name users.user_name%type;
    buyer_name users.user_name%type;
begin
    select items.seller_id, price into seller_id_, item_price from items where item_id = item_id_param;
    select user_name into seller_name from users where user_id = seller_id_;
    select user_name into buyer_name from users where user_id = user_id_param;
    insert into orders(item_id, user_id, amount) values(item_id_param, user_id_param, amount_param);
    update users set balance = balance - item_price * amount_param where user_id = user_id_param;
    update users set balance = balance + item_price * amount_param where user_id = seller_id_;
    update items set item_count = item_count - amount_param where item_id = item_id_param;
    raise notice '% bought % items from %', buyer_name, amount_param, seller_name;
end;
$$ language 'plpgsql';

-- a custom type for detailed order information
create type detailed_order_type as (
    order_id int,
    user_id int,
    item_id int,
    item_name varchar,
    item_description varchar,
    price decimal,
    amount int,
    total_spent decimal,
    category_name varchar,
    seller_id int,
    seller_name varchar,
    purchase_date timestamp
);

-- function to calculate the total revenue generated from item sales
create or replace function get_sold_amount(item_id items.item_id%type) returns decimal as
$$
declare
    my_cursor cursor for select * from detailed_orders;
    total_sold decimal;
    sold_amount detailed_order_type;
begin
    total_sold := 0;
    for sold_amount in my_cursor loop
        if sold_amount.item_id = item_id then
            total_sold := total_sold + sold_amount.amount;
        end if;
    end loop;
    return total_sold;
end;
$$ language 'plpgsql';

-- function to get the list of bought items for a user
create or replace function get_bought_items(user_id_param users.user_id%type) returns setof detailed_order_type as
$$
declare
    my_cursor cursor for select * from detailed_orders order by purchase_date desc;
    bought_item detailed_order_type;
begin
    for bought_item in my_cursor loop
        if bought_item.user_id = user_id_param then
            return next bought_item;
        end if;
    end loop;
    return;
end;
$$ language 'plpgsql';

------ Sample Data ------
-- Inserting sample data into the 'users' table
INSERT INTO users (user_name, hashed_password, first_name, last_name, phone_no, email, bdate, user_address, balance)
VALUES
    ('user1', '5c1ab95b59db0b69f53c8955ba7a9214c8e258fb7bc9622e6e1f2909516a0090', 'John', 'Doe', '555-1234', 'john.doe@example.com', '1990-01-15', '123 Main St, City', 100.00),
    ('user2', '45cf1c19da4fd682b7e5e9673ad09d093c4a98c3c81b0ca6ecdd14ed4edfc001', 'Jane', 'Smith', '555-5677', 'jane.smith@example.com', '1985-05-20', '456 Oak St, Town', 50.00),
    ('user3', '805309bfd598ab18a689e5861984aebcf94107775fa603e9adfdd53fc388fde8', 'Alice', 'Johnson', '555-4321', 'alice.johnson@example.com', '1992-03-22', '789 Pine St, Village', 75.00),
    ('user4', 'b5d1da79803819737d9555c85a6e2522a00328871ab7d3a1114ecc15e7d84161', 'Bob', 'Miller', '555-8765', 'bob.miller@example.com', '1988-08-10', '987 Elm St, Suburb', 120.00),
    ('user5', 'bc620faaac9a168b1910171d93af1d12704d96b83a2a0ee068d9aa6ab8bd470f', 'Eva', 'Williams', '555-5432', 'eva.williams@example.com', '1995-06-18', '654 Birch St, Town', 90.00),
    ('user6', '78f746200129e2149a10e03ed18170d7200311e12606061818b95d67af712ea6', 'David', 'Lee', '555-2345', 'david.lee@example.com', '1982-11-05', '321 Cedar St, City', 60.00),
    ('user7', '85557694187c93f1147a20aefb80c0ee8eea0163ce57f1430e49ed0bb092462c', 'Grace', 'Brown', '555-7654', 'grace.brown@example.com', '1998-09-30', '456 Oak St, Village', 110.00),
    ('user8', 'e1590285f1abeb0b990fa3d8497bea434f03226db199ea47162d6e1c18800345', 'Charlie', 'Jones', '555-3210', 'charlie.jones@example.com', '1980-04-14', '789 Maple St, Suburb', 30.00),
    ('user9', '0fc56ed5681a5c3d95b2fbdbba1fa84a99433d96503d04d077ef49296f5b016a', 'Olivia', 'White', '555-6789', 'olivia.white@example.com', '1993-07-26', '876 Walnut St, City', 80.00),
    ('user10', 'e000a3802b875391a45491b3ef280f8a68d7f0fc8dd3b23d5ae1ac170833d55b', 'Mason', 'Taylor', '555-4320', 'mason.taylor@example.com', '1987-02-08', '123 Pine St, Town', 95.00);


-- Inserting sample data into the 'category' table
INSERT INTO category (category_name)
VALUES
    ('Electronics'),
    ('Clothing'),
    ('Books'),
    ('Home Appliances'),
    ('Jewelry'),
    ('Toys'),
    ('Home Decor'),
    ('Handmade Crafts'),
    ('Sports Equipment'),
    ('Gourmet Food'),
    ('Beauty Products');


-- Inserting sample data into the 'items' table
INSERT INTO items (seller_id, item_name, item_description, price, item_count, category_id)
VALUES
    (1, 'Laptop', 'Brand new laptop', 1200.00, 5, 1),
    (2, 'T-shirt', 'Cotton T-shirt', 15.00, 20, 2),
    (3, 'Coffee Maker', 'Stainless steel coffee maker', 50.00, 10, 1),
    (4, 'Necklace', 'Handcrafted silver necklace', 40.00, 15, 2),
    (5, 'Action Figure', 'Collectible action figure', 12.00, 30, 3),
    (6, 'Throw Pillow Set', 'Set of decorative throw pillows', 25.00, 8, 4),
    (8, 'Hand-painted Canvas', 'Original artwork on canvas', 60.00, 5, 1),
    (10, 'Football', 'Official size and weight', 30.00, 12, 3),
    (2, 'Earrings', 'Artisan-crafted earrings', 18.00, 20, 2),
    (7, 'Luxury Soap Set', 'Assorted handmade soaps', 15.00, 25, 5);

-- Inserting sample data into the 'orders' table
SELECT buy_item(6, 3, 1);
SELECT buy_item(9, 4, 2);
SELECT buy_item(7, 5, 3);
SELECT buy_item(4, 2, 2);
SELECT buy_item(1, 2, 3);
SELECT buy_item(3, 6, 2);
SELECT buy_item(10, 7, 1);
SELECT buy_item(5, 8, 3);
SELECT buy_item(8, 9, 1);
SELECT buy_item(4, 10, 2);